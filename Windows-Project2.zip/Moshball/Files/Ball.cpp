#include "Ball.h"

bool Ball::compiled;
GLuint Ball::displayList;

Ball::Ball()
{
	if(!Ball::compiled) {
        Ball::compileDL();
    }
    pos.set(0.0,0.0,0.0);
    dir.set(0.0,0.0,-1.0);
    vel = 0;
    unhit();
}

Ball::~Ball()
{
    
}

void Ball::compileDL()
{
    if(Ball::compiled) return;
    Ball::displayList = glGenLists(1);
    glNewList(Ball::displayList, GL_COMPILE);
    gluSphere(gluNewQuadric(),BALL_RADIUS,50,50);
    glEndList();
    Ball::compiled = true;
}

void Ball::draw()
{
    if(!Ball::compiled) return;
    glCallList(Ball::displayList);
}

void Ball::drawAtPosition()
{
    if(active) 
    {
        this->displayTimer();
    }    
    setGLColor();
    
    glPushMatrix();
    glTranslated(pos[0], pos[1], pos[2]);
	GLfloat c = 1000.0/this->pos[0];
	Model::shader3->setCloseness(c);
	if(Model::use_shader3) Model::shader3->UseProgram();
	else Model::shader1->UseProgram();
    draw();
	glUseProgram(0);
    glPopMatrix();
}


bool Ball::checkCollisionWithMovable(Movable * m)
{
    if(m->pos[0] > this->pos[0]-(BALL_RADIUS*2) && m->pos[0] < this->pos[0]+(BALL_RADIUS*2) &&
       m->pos[1] > this->pos[1]-(BALL_RADIUS*2) && m->pos[1] < this->pos[1]+(BALL_RADIUS*2) &&
       m->pos[2] > this->pos[2]-(BALL_RADIUS*2) && m->pos[2] < this->pos[2]+(BALL_RADIUS*2))
    {
        this->hit();
        return true;
    }
    return false;
}

void Ball::hit()
{
	Model::hl = 1.0;
	if(!this->active) Model::ballsLeft--;
	if(Model::ballsLeft == 0)
	{
		std::cout << "Game contained " << Model::numBalls << " targets." << std::endl;
		std::cout << "Game ended at time: " << Model::totalTime << " seconds." << std::endl;
		std::cout << "Game has been won." << std::endl;
		glutLeaveMainLoop();
	}
    this->active = true;
    this->timeLeft = Model::fullTime;
    setColor(1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.5f, 0.1f);
}

void Ball::unhit()
{
	if(this->active) Model::ballsLeft++;
    this->active = false;
    this->timeLeft = 0;
    setColor(0.0, 1.0, 0.0, 1.0, 1.0, 0.5, 0.1f);
}

void Ball::updateTime()
{
    if(active)
    {
        timeLeft = timeLeft - Model::timePassed;
        if(timeLeft <= 0)
            unhit();
    }
}

void Ball::displayTimer()
{
    glEnable(GL_ALPHA_TEST);
	glPushMatrix();
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTranslatef(this->pos[0], BALL_RADIUS * 1.25, this->pos[2]);
		GLfloat angle = Model::radiansToDegrees(atan2(this->pos[0] - Model::player->pos[0], this->pos[2] - Model::player->pos[2]));
		glRotatef(angle+180, 0.0f, 1.0f, 0.0f);
		glTranslatef(-BALL_RADIUS * .5, 0.0f, 0.0f);
		glScalef(.25, .25, 1.0);
		freetype::print(Model::our_font, 0.0f, 0.0, 0.0f, "%.2f", this->timeLeft);
	glPopMatrix();
	glDisable(GL_ALPHA_TEST);
}