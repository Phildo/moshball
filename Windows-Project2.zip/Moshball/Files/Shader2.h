#ifndef SHADER_2_H
#define SHADER_2_H

#include "Shader.h"

class Shader2: public Shader
{
public:
	Shader2();
	GLuint hitLeft;

	void InitializeUniforms();
	void setHitLeft(GLfloat h);
};
#endif