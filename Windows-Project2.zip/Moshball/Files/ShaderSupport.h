#ifndef SHADER_SUPPORT_H
#define SHADER_SUPPORT_H

#include <glew.h>
#include <freeglut.h>
#include <iostream>
#include <sstream>
#include <string>
#include <assert.h>

class ShaderSupport
{
public:
	static void CheckGLErrors(std::string & caller);
	static void LoadShader(const char * file_name, GLuint shader_id);
	static std::stringstream GetShaderLog(GLuint shader_id);
	static std::stringstream GetGLInfo();
};

class ShaderHandles
{
public:
	GLuint vertex_shader_id;
	GLuint fragment_shader_id;
	GLuint program_id;

	ShaderHandles();
	void InitializeShader(std::string vertex_shader_file, std::string fragment_shader_file);
	void TakeDown();
	void UseProgram();
	inline GLuint GetProgramID()
	{
		return program_id;
	}
	virtual void InitializeMappings() abstract;
	virtual void InitializeUniforms() abstract;
};

#endif