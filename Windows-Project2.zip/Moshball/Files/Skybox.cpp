//
//  Skybox.cpp
//  MoshBall
//
//  Created by Philip Dougherty on 11/30/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#include "Skybox.h"

bool Skybox::compiled;
GLuint Skybox::displayList;
GLuint Skybox::texture_id;

Skybox::Skybox()
{
	if(!Skybox::compiled) {
        Skybox::compileDL();
    }
}

Skybox::~Skybox()
{
    
}

void Skybox::compileDL()
{
	if(Skybox::compiled) return;
	glGenTextures(1, &Skybox::texture_id);
	Skybox::texture_id = ilutGLLoadImage("L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\skybox_texture.jpg");
	Skybox::displayList = glGenLists(1);
    glNewList(Skybox::displayList, GL_COMPILE);
	glDisable(GL_LIGHTING);
	glColor4f(1.0,1.0,1.0,1.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, Skybox::texture_id);
    glBegin(GL_QUADS);


    //Ceiling
    //glNormal3d(0.0, 1.0, 0.0);
	glTexCoord2d(0.25, 2.0/3.0); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.5, 2.0/3.0); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.5, 1); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(0.25, 1); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
    
    //West Wall
    //glNormal3d(1.0, 0.0, 0.0);
	glTexCoord2d(0.0, 2.0/3.0); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(0.25, 2.0/3.0); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.25, 1.0/3.0); glVertex3d(-ARENA_WIDTH, -SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.0, 1.0/3.0); glVertex3d(-ARENA_WIDTH, -SKY_HEIGHT, -ARENA_LENGTH);
    
    //East Wall
    //glNormal3d(-1.0, 0.0, 0.0);
	glTexCoord2d(0.75, 2.0/3.0); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(0.5, 2.0/3.0); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.5, 1.0/3.0); glVertex3d(ARENA_WIDTH, -SKY_HEIGHT, ARENA_LENGTH);
	glTexCoord2d(0.75, 1.0/3.0); glVertex3d(ARENA_WIDTH, -SKY_HEIGHT, -ARENA_LENGTH);
    
    //North Wall
    //glNormal3d(0.0, 0.0, 1.0);
	glTexCoord2d(1.0, 2.0/3.0); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(0.75, 2.0/3.0); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(0.75, 1.0/3.0); glVertex3d(ARENA_WIDTH, -SKY_HEIGHT, -ARENA_LENGTH);
	glTexCoord2d(1.0, 1.0/3.0); glVertex3d(-ARENA_WIDTH, -SKY_HEIGHT, -ARENA_LENGTH);
    
    //South Wall
    //glNormal3d(0.0, 0.0, -1.0);
    glTexCoord2d(0.25, 2.0/3.0); glVertex3d(-ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
    glTexCoord2d(0.5, 2.0/3.0); glVertex3d(ARENA_WIDTH, SKY_HEIGHT, ARENA_LENGTH);
    glTexCoord2d(0.5, 1.0/3.0); glVertex3d(ARENA_WIDTH, -SKY_HEIGHT, ARENA_LENGTH);
    glTexCoord2d(0.25, 1.0/3.0); glVertex3d(-ARENA_WIDTH, -SKY_HEIGHT, ARENA_LENGTH);
    
    glEnd();
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
    glEndList();
    Skybox::compiled = true;
}

void Skybox::draw()
{
	if(!Skybox::compiled) return;
    glCallList(Skybox::displayList);
}