#ifndef SHADER_3_H
#define SHADER_3_H

#include "Shader.h"

class Shader3: public Shader
{
	public:
	Shader3();
	GLuint closeness;

	void InitializeUniforms();
	void setCloseness(GLfloat c);
};
#endif