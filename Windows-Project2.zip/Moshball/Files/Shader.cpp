#include "Shader.h"

Shader::Shader() : ShaderHandles()
{
	//mode_id = -1;//projection_matrix_id = modelview_matrix_id = -1;
	//mode = 0;
}

void Shader::InitializeUniforms()
{
	assert(this->program_id != -1);
	//UseProgram();
	//modelview_matrix_id = glGetUniformLocation(program_id, (const GLchar *) "modelview_matrix");
	//projection_matrix_id = glGetUniformLocation(program_id, (const GLchar *) "projection_matrix");
	//offset_id = glGetUniformLocation(program_id, (const GLchar *) "offset");
	//mode_id = glGetUniformLocation(program_id, (const GLchar *) "mode");
	//assert(modelview_matrix_id != -1);
	//assert(projection_matrix_id != -1);
	//assert(mode_id != -1);
	//assert(offset_id != -1);
	//glUniform1i(mode_id, mode);
	// ShaderSupport::CheckGLErrors(string("InitialzeUniforms"));
}

void Shader::InitializeMappings()
{
}

void Shader::SetModelviewMatrix(const glm::mat4 & mv)
{
	//glUniformMatrix4fv(modelview_matrix_id, 1, GL_FALSE, glm::value_ptr(mv));
	// ShaderSupport::CheckGLErrors(string("SetMVP"));
}

void Shader::SetOffset(float offset)
{
	//glUniform1f(offset_id, offset);
}

void Shader::IncrementMode()
{
	//UseProgram();
	//mode = (mode + 1) % 4;
	//glUniform1i(mode_id, mode);
	//glUseProgram(0);
}

void Shader::SetProjectionMatrix(const glm::mat4 & p)
{
	//glUniformMatrix4fv(projection_matrix_id, 1, GL_FALSE, glm::value_ptr(p));
	// ShaderSupport::CheckGLErrors(string("SetProjectionMatrix"));
}