#include "Shader3.h"

Shader3::Shader3() : Shader()
{
	//hitLeft = -1;
}

void Shader3::InitializeUniforms()
{
	assert(this->program_id != -1);
	UseProgram();
	closeness = glGetUniformLocation(this->program_id, (const GLchar *) "closenessUni");
	//assert(hitLeft != -1);
	glUseProgram(0);
}

void Shader3::setCloseness(GLfloat c)
{
	UseProgram();
	glUniform1f(closeness, (float)c);
	glUseProgram(0);
}