#ifndef	SHADER_H
#define	SHADER_H
#include <string>
#include <iostream>
#include <assert.h>
#include <vector>
#include <stack>
#include <glew.h>
#include <freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/matrix_operation.hpp>
#include "ShaderSupport.h"

class Shader : public ShaderHandles
{
public:
	GLuint modelview_matrix_id;
	GLuint projection_matrix_id;
	GLuint offset_id;
	GLuint mode_id;

	int mode;

	Shader();

	virtual void InitializeUniforms();

	virtual void InitializeMappings();

	void SetModelviewMatrix(const glm::mat4 & mv);

	void SetOffset(float offset);

	void IncrementMode();

	void SetProjectionMatrix(const glm::mat4 & p);

};
#endif