//
//  Model.cpp
//  MoshBall
//
//  Created by Philip Dougherty on 11/6/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#include "Model.h"

int Model::numBalls;
int Model::seed;
double Model::fullTime;

HighPrecisionTime * Model::hTime;
double Model::timePassed;
double Model::totalTime;

int Model::ballsLeft = Model::numBalls;

bool Model::paused = false;
bool Model::wireFrame = false;
bool Model::billards = false;

Player * Model::player;
Arena * Model::arena;
Skybox * Model::skybox;
Ball ** Model::balls;
Arrow * Model::compass;
Jumbotron * Model::jOne;
Jumbotron * Model::jTwo;
Jumbotron * Model::jThree;
Jumbotron * Model::jFour;

Shader1 * Model::shader1;
Shader2 * Model::shader2;
GLfloat Model::hl;
Shader3 * Model::shader3;
GLfloat Model::c;

bool Model::use_shader1 = true;
bool Model::use_shader2 = true;
bool Model::use_shader3 = true;

freetype::font_data Model::our_font;

Vector3 Model::UpVect;
Vector3 Model::DownVect;
Vector3 Model::NorthVect;
Vector3 Model::SouthVect;
Vector3 Model::WestVect;
Vector3 Model::EastVect;

void Model::setUpModel()
{
	hTime = new HighPrecisionTime();
	timePassed = 0;
	totalTime = 0;

    arena = new Arena();
    skybox = new Skybox();
    player = new Player();
    balls = new Ball*[Model::numBalls];
    compass = new Arrow();
    jOne = new Jumbotron();
    jTwo = new Jumbotron();
    jThree = new Jumbotron();
    jFour = new Jumbotron();

	shader1 = new Shader1();
	shader2 = new Shader2();
	hl = 0;
	shader3 = new Shader3();
	c = 0;
    
    UpVect.set   ( 0, 1, 0);
    DownVect.set ( 0,-1, 0);
    NorthVect.set( 0, 0,-1);
    SouthVect.set( 0, 0, 1);
    WestVect.set (-1, 0, 0);
    EastVect.set ( 1, 0, 0);

	shader1->InitializeShader("L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\vertex_shader1", "L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\fragment_shader1");
	shader2->InitializeShader("L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\vertex_shader2", "L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\fragment_shader2");
	shader2->InitializeUniforms();
	shader2->setHitLeft(hl);
	shader3->InitializeShader("L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\vertex_shader3", "L:\\My Documents\\Visual Studio 2010\\Projects\\Moshball\\Files\\fragment_shader3");
	shader3->InitializeUniforms();
	shader3->setCloseness(c);
	our_font.init("C:\\Windows\\Fonts\\Arial.ttf", 72);
}

////////////////////
//HELPER FUNCTIONS//
////////////////////
double Model::rangeRand(double start, double end)
{
    return ((rand()/(double)RAND_MAX)*(end-start))+start;
}
GLfloat Model::degreesToRadians(GLfloat degrees)
{
	return (GLfloat) (degrees / 180 * 3.141592);
}
GLfloat Model::radiansToDegrees(GLfloat radians)
{
	return (GLfloat) (radians / 3.141592 * 180);
}

double Model::updateTime()
{
	timePassed = hTime->TimeSinceLastCall();
	if(paused)
	{
		timePassed = 0.0;
	}
	totalTime+=timePassed;
	if(hl > 0) hl-=(GLfloat)0.01;
	if(hl < 0) hl = 0;
	std::cout << hl << std::endl;
	shader2->setHitLeft(hl);
	return timePassed;
}