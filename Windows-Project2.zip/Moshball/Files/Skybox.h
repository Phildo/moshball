//
//  Skybox.h
//  MoshBall
//
//  Created by Philip Dougherty on 11/30/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#ifndef SKYBOX_H
#define SKYBOX_H
#undef _UNICODE
#define ILUT_USE_OPENGL

#include "Model.h"
#include <freeglut.h>
#include <glext.h>
#include <IL/il.h>
#include <IL/ilu.h>
#include <IL/ilut.h>
#include "DrawableGeometry.h"

class Skybox: public DrawableGeometry
{
public:
    Skybox();
    ~Skybox();
    
    void compileDL();
    void draw();

	static GLuint texture_id;
    
protected:
    static bool compiled;
    static GLuint displayList;
	//static GLuint texture_id;

};

#endif