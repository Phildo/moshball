//
//  Jumbotron.cpp
//  MoshBall
//
//  Created by Philip Dougherty on 10/30/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#include "Jumbotron.h"

bool Jumbotron::compiled;
GLuint Jumbotron::displayList;
GLuint Jumbotron::texture_id[2];
int Jumbotron::curRecCount = 0;

Jumbotron::Jumbotron()
{
	if(!Jumbotron::compiled) {
        setColor(1.0, 0.5, 0.5, 1.0, 0.25, 0.25, 0.5);
        Jumbotron::compileDL();
    }
}

Jumbotron::~Jumbotron()
{
}

void Jumbotron::compileDL()
{
    if(Jumbotron::compiled) return;
    Jumbotron::displayList = glGenLists(1);
    glNewList(Jumbotron::displayList, GL_COMPILE);
    glPushMatrix();
		setGLColor();
		glRotated(90.0, 1.0, 0.0, 0.0);
		glTranslated(0.0, 0.0, -200.0);
		gluCylinder(gluNewQuadric(), 20, 20, 200, 50, 50);
    glPopMatrix();
    glPushMatrix();
		glTranslated(0, 300, 0);
		glBegin(GL_TRIANGLES);
		/*
		glDisable(GL_LIGHTING);
		glColor4f(1.0,1.0,1.0,1.0);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, texture_id);
    
		glTexCoord2d(0.0, 0.0); glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 0.0); glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 1.0); glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);

		glTexCoord2d(0.0, 0.0); glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 1.0); glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(0.0, 1.0); glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);

		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LIGHTING);
    */
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, -.5*J_THICK);
    
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, -.5*J_THICK);
    
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
		glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, -.5*J_THICK);
    
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
    
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
		glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, -.5*J_THICK);
    
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
    
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
    
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, -.5*J_THICK);
		glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);

		glEnd();
    glPopMatrix();
    
    glEndList();
    Jumbotron::compiled = true;
}

void Jumbotron::drawScreen()
{
    if(curRecCount == 0) return;
    glPushMatrix();
		glTranslated(0, 300, 0);
		glDisable(GL_LIGHTING);
		glColor4f(1.0,1.0,1.0,1.0);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, Jumbotron::texture_id[(curRecCount+1)%2]);

		glBegin(GL_TRIANGLES);
		glTexCoord2d(0.0, 0.0); glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 0.0); glVertex3d(.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 1.0); glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);

		glTexCoord2d(0.0, 0.0); glVertex3d(-.5*J_WIDTH, -.5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(1.0, 1.0); glVertex3d(.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
		glTexCoord2d(0.0, 1.0); glVertex3d(-.5*J_WIDTH, .5*J_HEIGHT, .5*J_THICK);
		glEnd();

		glDisable(GL_TEXTURE_2D);
		glEnable(GL_LIGHTING);
	glPopMatrix();
}

void Jumbotron::draw()
{
    if(!Jumbotron::compiled) return;
	glCallList(Jumbotron::displayList);
}