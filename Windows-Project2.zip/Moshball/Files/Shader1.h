#ifndef SHADER_1_H
#define SHADER_1_H

#include "Shader.h"

class Shader1: public Shader
{

};
#endif