//
//  Model.h
//  MoshBall
//
//  Created by Philip Dougherty on 11/6/11.
//  Copyright 2011 UW Madison. All rights reserved.
//
#ifndef	MODEL_H
#define	MODEL_H

#define ARENA_WIDTH  5280
#define ARENA_LENGTH 5280
#define ARENA_HEIGHT 100
#define SKY_HEIGHT 5280

#define J_WIDTH 300
#define J_HEIGHT 200
#define J_THICK 40
#define J_RECURSE 5

#define COMPASS_DISTANCE 3750
#define HUD_WIDTH COMPASS_DISTANCE*2+100
#define HUD_HEIGHT COMPASS_DISTANCE*2+100

#define NUM_MODES 2
#define NUM_BALLS 50
#define SEED 0

#define MOVEMENT_TOLERANCE 0.025
#define SPEED 5000
#define ROT_SPEED 250
#define FRICTION 0.995

#define BALL_RADIUS 50
//#define FULL_TIME (30+(NUM_BALLS*2))

#define NO_COLLISION 999999999.0


#include <glew.h>
#include <time.h>
#include "VectorLib/Vectors.h"
#include "Player.h"
#include "Ball.h"
#include "Arena.h"
#include "Skybox.h"
#include "Arrow.h"
#include "Jumbotron.h"
#include "highprecisiontime.h"
#include "Shader.h"
#include "Shader1.h"
#include "Shader2.h"
#include "Shader3.h"

#include "my_freetype.h"

class Player;
class Ball;
class Skybox;
class Arena;
class Arrow;
class Jumbotron;
class Shader;

class Model{
public:

	//Command Input
	static int numBalls;
	static int seed;
	static double fullTime;
    
    static HighPrecisionTime *hTime;
	static double timePassed;
	static double totalTime;

	static int ballsLeft;
    
	static bool paused;
	static bool wireFrame;
	static bool billards;

    static Player *player;
    static Ball **balls;
    static Skybox *skybox;
    static Arena *arena;
    static Arrow *compass;
    static Jumbotron *jOne;
    static Jumbotron *jTwo;
    static Jumbotron *jThree;
    static Jumbotron *jFour;
    
	static Shader1 *shader1;
	static Shader2 *shader2;
	static GLfloat hl;
	static Shader3 *shader3;
	static GLfloat c;

	static bool use_shader1;
	static bool use_shader2;
	static bool use_shader3;

    static Vector3 UpVect;
    static Vector3 DownVect;
    static Vector3 NorthVect;
    static Vector3 SouthVect;
    static Vector3 WestVect;
    static Vector3 EastVect;

	static freetype::font_data our_font;
    
    static void setUpModel();
	static GLfloat radiansToDegrees(GLfloat radians);
	static GLfloat degreesToRadians(GLfloat degrees);
	static double rangeRand(double start, double end);
    static double updateTime();
};
#endif
