#include "Shader2.h"

Shader2::Shader2() : Shader()
{
	//hitLeft = -1;
}

void Shader2::InitializeUniforms()
{
	assert(this->program_id != -1);
	UseProgram();
	hitLeft = glGetUniformLocation(this->program_id, (const GLchar *) "hitLeftUni");
	//assert(hitLeft != -1);
	glUseProgram(0);
}

void Shader2::setHitLeft(GLfloat h)
{
	UseProgram();
	glUniform1f(hitLeft, (float)h);
	glUseProgram(0);
}