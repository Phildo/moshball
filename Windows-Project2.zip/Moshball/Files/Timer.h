//
//  Timer.h
//  MoshBall
//
//  Created by Philip Dougherty on 10/30/11.
//  Copyright 2011 UW Madison. All rights reserved.
//
//  Floating text of a Timer

class Timer
{
public:
    
};