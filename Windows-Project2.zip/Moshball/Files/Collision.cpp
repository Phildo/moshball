//
//  Collision.cpp
//  MoshBall
//
//  Created by Philip Dougherty on 11/20/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#include "Collision.h"


Collision::Collision()
{
    timePassed = 99999999999999.0;
}

Collision::~Collision()
{
    
}