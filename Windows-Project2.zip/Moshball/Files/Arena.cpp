#include "Arena.h"

bool Arena::compiled;
GLuint Arena::displayListFloor;
GLuint Arena::displayListWalls;

Arena::Arena()
{
	if(!Arena::compiled) {
        Arena::compileDL();
    }
}

Arena::~Arena()
{

}

void Arena::compileDL()
{
    if(Arena::compiled) return;
    Arena::displayListFloor = glGenLists(1);
    glNewList(Arena::displayListFloor, GL_COMPILE);
 
    setColor(0.5, 0.25, 0.5, 1.0, 0.25, 0.25, 0.5);
    setGLColor();
 
    glBegin(GL_QUADS);
 
    //Floor
    glNormal3d(0.0, 1.0, 0.0);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
 
 
    setColor(0.5, 0.5, 0.0, 1.0, 0.25, 0.25, 0.5);
    setGLColor();

	glEnd();
    glEndList();
 
	Arena::displayListWalls = glGenLists(1);
    glNewList(Arena::displayListWalls, GL_COMPILE);
 
    setColor(0.5, 0.25, 0.5, 1.0, 0.25, 0.25, 0.5);
    setGLColor();
 
    glBegin(GL_QUADS);

    //West Wall
    glNormal3d(1.0, 0.0, 0.0);
    glVertex3d(-.5*ARENA_WIDTH, .5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, .5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
 
    //East Wall
    glNormal3d(-1.0, 0.0, 0.0);
    glVertex3d(.5*ARENA_WIDTH, .5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, .5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
 
    //North Wall
    glNormal3d(0.0, 0.0, 1.0);
    glVertex3d(-.5*ARENA_WIDTH, .5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, .5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, -.5*ARENA_LENGTH);
 
    //South Wall
    glNormal3d(0.0, 0.0, -1.0);
    glVertex3d(-.5*ARENA_WIDTH, .5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, .5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
    glVertex3d(-.5*ARENA_WIDTH, -.5*ARENA_HEIGHT, .5*ARENA_LENGTH);
 
    glEnd();
    glEndList();
    Arena::compiled = true;
}

void Arena::draw()
{
    if(!Arena::compiled) return;
	Model::shader2->UseProgram();
	glCallList(Arena::displayListFloor);
	glUseProgram(0);
	Model::shader1->UseProgram();
    glCallList(Arena::displayListWalls);
	glUseProgram(0);
}