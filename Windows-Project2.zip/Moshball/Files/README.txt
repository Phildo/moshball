|////////////////////////////|
|\\\\\\\\\\\\\\\\\\\\\\\\\\\\|
|/////Philip Dougherty///////| 
|\\\\\\Nick Pjevach \\\\\\\\\|
|////////////////////////////|
|\\\\\\\\\\\\\\\\\\\\\\\\\\\\|


Talking Points

	Things Different
		- Billiards (saves energy)
		- Non-linear response to mouse movement
		- Compass
		- Modularized code, with model and inheritance of classes for movement and drawing
		- N-recursion in jumbotron	
